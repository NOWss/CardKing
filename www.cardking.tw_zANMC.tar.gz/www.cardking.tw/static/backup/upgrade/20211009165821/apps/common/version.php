<?php
return array(
    // 应用版本
    'app_version' => '3.0.6',
    
    // 发布时间
    'release_time' => '20210929',
    
    // 修订版本
    'revise_version' => '0'

);
